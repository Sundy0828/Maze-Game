﻿Public Class LevelOne

    Dim score As Integer = 1000

    Private Function CheckReset() As Boolean

        For Each ctl As Control In Me.Controls
            If ctl.GetType Is GetType(PictureBox) And ctl.Name <> "PictureBox1" Then
                If CType(ctl, PictureBox).Bounds.IntersectsWith(PictureBox1.Bounds) Then
                    Return True
                End If
            End If
        Next

        Return False
    End Function

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Up Then
            PictureBox1.Top = PictureBox1.Top - 5
        End If
        If e.KeyCode = Keys.Left Then
            PictureBox1.Left = PictureBox1.Left - 5
        End If
        If e.KeyCode = Keys.Right Then
            PictureBox1.Left = PictureBox1.Left + 5
        End If
        If e.KeyCode = Keys.Down Then
            PictureBox1.Top = PictureBox1.Top + 5
        End If

        If lblfinish.Bounds.IntersectsWith(PictureBox1.Bounds) Then
            Timer1.Enabled = False
            LevelTwo.lblScore2.Text = lblScore1.Text
            MessageBox.Show("Your score is: " & lblScore1.Text, "Level 1 Complete")
            CheckReset()
            LevelTwo.Show()
            Me.Close()
        End If

        If CheckReset() Then
            PictureBox1.Top = 548
            PictureBox1.Left = 346
        End If

        If Label6.Bounds.IntersectsWith(PictureBox1.Bounds) Then
            PictureBox1.Top = 368
            PictureBox1.Left = 774
        End If


    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        lblScore1.Text = lblScore1.Text - 2
    End Sub

End Class