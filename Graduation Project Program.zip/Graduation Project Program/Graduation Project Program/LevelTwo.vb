﻿Public Class LevelTwo

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()

    End Sub
    Private Sub lvl2_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Up Then
            PictureBox7.Top = PictureBox7.Top - 3
        End If
        If e.KeyCode = Keys.Left Then
            PictureBox7.Left = PictureBox7.Left - 3
        End If
        If e.KeyCode = Keys.Right Then
            PictureBox7.Left = PictureBox7.Left + 3
        End If
        If e.KeyCode = Keys.Down Then
            PictureBox7.Top = PictureBox7.Top + 3
        End If

        If PictureBox44.Bounds.IntersectsWith(PictureBox7.Bounds) Then
            PictureBox7.Top = 416
            PictureBox7.Left = 1011
        End If

        If CheckReset() Then
            PictureBox7.Top = 47
            PictureBox7.Left = 300
        End If

        If finish.Bounds.IntersectsWith(PictureBox7.Bounds) Then
            Timer1.Enabled = False
            LastLevel.lblScore3.Text = lblScore2.Text
            MessageBox.Show("Your score is: " & lblScore2.Text, "Level 2 Complete")
            CheckReset()
            LastLevel.Show()
            Me.Close()
        End If

    End Sub
    Private Function CheckReset() As Boolean

        For Each ctl As Control In Me.Controls
            If ctl.GetType Is GetType(PictureBox) And ctl.Name <> "PictureBox7" Then
                If CType(ctl, PictureBox).Bounds.IntersectsWith(PictureBox7.Bounds) Then
                    Return True
                End If
            End If
        Next

        Return False
    End Function

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        lblScore2.Text = lblScore2.Text - 2

    End Sub

    Private Sub lvl3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()

    End Sub

End Class