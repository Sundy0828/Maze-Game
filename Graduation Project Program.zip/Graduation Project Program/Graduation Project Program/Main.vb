﻿Imports System.IO

Public Class Main

#Region "change color of labels"
    Private Sub ColorBack()
        If Label2.ForeColor = Color.Cyan Then
            Label2.ForeColor = Color.Blue
        End If
        If Label3.ForeColor = Color.Cyan Then
            Label3.ForeColor = Color.Blue
        End If
        If Label4.ForeColor = Color.Cyan Then
            Label4.ForeColor = Color.Blue
        End If
        If Label5.ForeColor = Color.Cyan Then
            Label5.ForeColor = Color.Blue
        End If
    End Sub

    Sub ColorChanger(LabelNum)
        If LabelNum.ForeColor = Color.Blue Then
            LabelNum.ForeColor = Color.Cyan
        End If
    End Sub

    Private Sub Label2_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label2.MouseHover
        ColorChanger(Label2)
    End Sub

    Private Sub Label3_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label3.MouseHover
        ColorChanger(Label3)
    End Sub

    Private Sub Label4_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label4.MouseHover
        ColorChanger(Label4)
    End Sub

    Private Sub Label5_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label5.MouseHover
        ColorChanger(Label5)
    End Sub

    Private Sub PictureBox1_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label1.MouseHover, PictureBox2.MouseHover, Me.MouseHover, PictureBox3.MouseHover, Panel1.MouseHover
        ColorBack()
    End Sub
#End Region

#Region "Buttons"
    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        Instructions.Show()
        Me.Hide()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Me.Close()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        LevelOne.Show()
        Me.Hide()
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        HighScores.Show()
        Me.Hide()
    End Sub
#End Region

End Class
