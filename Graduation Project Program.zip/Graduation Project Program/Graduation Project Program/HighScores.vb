﻿Imports System.IO

Public Class HighScores
    Dim Records As New List(Of Scores)
    Dim path As String = System.IO.Path.GetDirectoryName( _
           System.Reflection.Assembly.GetExecutingAssembly().Location) & "\HighScores.txt"

#Region "Buttons, form load"
    'when form is closed it shows main form
    Private Sub HighScores_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Main.Show()
    End Sub

    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Me.Close()
    End Sub

    Private Sub HighScores_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If IO.File.Exists(path) Then
            ReadLines()
            Search()
        End If
    End Sub
#End Region

#Region "Read lines & Create class"
    Public Class Scores

        'makeing fields for object class
        Private mnName As String
        Private mnScore As Integer
        Private mnDateScored As Date

        Property Name() As String
            Get
                Return mnName
            End Get
            Set(ByVal Value As String)
                mnName = Value
            End Set
        End Property

        Property Score() As String
            Get
                Return mnScore
            End Get
            Set(ByVal Value As String)
                mnScore = Value
            End Set
        End Property

        Property DateScored() As String
            Get
                Return mnDateScored
            End Get
            Set(ByVal Value As String)
                mnDateScored = Value
            End Set
        End Property
    End Class

    Sub ReadLines()
        Try
            Using MyReader As New Microsoft.VisualBasic.
                            FileIO.TextFieldParser(path)

                'spliting fields apart
                MyReader.TextFieldType = FileIO.FieldType.Delimited
                MyReader.SetDelimiters(",")
                Dim currentRow() As String
                While Not MyReader.EndOfData
                    Try
                        'adding fields to list of score objects
                        currentRow = MyReader.ReadFields()
                        Dim MyScore As New Scores
                        With MyScore
                            .Name = currentRow(0)
                            .Score = currentRow(1)
                            .DateScored = currentRow(2)
                        End With
                        Records.Add(MyScore)
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try
                End While
            End Using
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
#End Region

#Region "Search records"
    Sub Search()

        'searching records with link query
        Dim Record = From Rec In Records
                Order By Rec.Score Descending, Rec.DateScored Descending

        Dim Count As Integer = 0
        ' Output the results. 
        For Each Rec As Scores In Record
            If Rec IsNot Nothing And Count < 10 Then
                Select Case Count
                    Case 0
                        Label21.Text = Rec.Name
                        Label31.Text = Rec.Score
                    Case 1
                        Label20.Text = Rec.Name
                        Label30.Text = Rec.Score
                    Case 2
                        Label19.Text = Rec.Name
                        Label29.Text = Rec.Score
                    Case 3
                        Label18.Text = Rec.Name
                        Label28.Text = Rec.Score
                    Case 4
                        Label17.Text = Rec.Name
                        Label27.Text = Rec.Score
                    Case 5
                        Label16.Text = Rec.Name
                        Label26.Text = Rec.Score
                    Case 6
                        Label15.Text = Rec.Name
                        Label25.Text = Rec.Score
                    Case 7
                        Label14.Text = Rec.Name
                        Label24.Text = Rec.Score
                    Case 8
                        Label13.Text = Rec.Name
                        Label23.Text = Rec.Score
                    Case 9
                        Label12.Text = Rec.Name
                        Label22.Text = Rec.Score
                    Case Else
                        Exit For
                End Select
                Count = Count + 1
            End If
        Next
    End Sub
#End Region

#Region "change color of labels"
    Private Sub ColorBack()
        If Back.ForeColor = Color.Cyan Then
            Back.ForeColor = Color.Black
        End If
    End Sub

    Sub ColorChanger(LabelNum)
        If LabelNum.ForeColor = Color.Black Then
            LabelNum.ForeColor = Color.Cyan
        End If
    End Sub

    Private Sub Back_MouseHover(sender As Object, e As EventArgs) Handles Back.MouseHover
        ColorChanger(Back)
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.MouseHover
        ColorBack()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.MouseHover
        ColorBack()
    End Sub
#End Region

End Class