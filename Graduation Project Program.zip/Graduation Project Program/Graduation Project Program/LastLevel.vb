﻿Imports System.IO

Public Class LastLevel
    'get path of where application is saved
    Dim path As String = System.IO.Path.GetDirectoryName( _
           System.Reflection.Assembly.GetExecutingAssembly().Location) & "\HighScores.txt"

#Region "Maze controls, wall function, Timers"
    Private Sub lvl2_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Up Then
            PictureBox7.Top = PictureBox7.Top - 3
        End If
        If e.KeyCode = Keys.Left Then
            PictureBox7.Left = PictureBox7.Left - 3
        End If
        If e.KeyCode = Keys.Right Then
            PictureBox7.Left = PictureBox7.Left + 3
        End If
        If e.KeyCode = Keys.Down Then
            PictureBox7.Top = PictureBox7.Top + 3
        End If

        If CheckReset() Then
            PictureBox7.Top = 311
            PictureBox7.Left = 551
        End If

        If finish.Bounds.IntersectsWith(PictureBox7.Bounds) Then
            CheckReset()
            Timer1.Enabled = False
            saveScore()
            Main.Show()
            Me.Close()
        End If

        If Label5.Bounds.IntersectsWith(PictureBox7.Bounds) Then
            PictureBox7.Height = 5
            PictureBox7.Width = 5
        End If

        If Label6.Bounds.IntersectsWith(PictureBox7.Bounds) Then
            PictureBox7.Top = 285
            PictureBox7.Left = 219
        End If

    End Sub
    Private Function CheckReset() As Boolean

        For Each ctl As Control In Me.Controls
            If ctl.GetType Is GetType(PictureBox) And ctl.Name <> "PictureBox7" Then
                If CType(ctl, PictureBox).Bounds.IntersectsWith(PictureBox7.Bounds) Then
                    Return True
                End If
            End If
        Next

        Return False
    End Function

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        lblScore3.Text = lblScore3.Text - 2
    End Sub

    Private Sub lvl3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub
#End Region

#Region "Buttons"
    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub
#End Region

#Region "Save score"
    Private Sub saveScore()
        'generating the name
        'has to be 3 characters and letters only
        'loops through until name meets standards
        Dim Name As String = ""
        Do Until Name.Count = 3 And System.Text.RegularExpressions.Regex.IsMatch(Name, "^[A-Za-z]+$")
            Name = InputBox("You Win" & ControlChars.NewLine & "Your score is: " & lblScore3.Text _
                            & ControlChars.NewLine & "Enter Name Here (3 Letters)", "Level 3 Complete")
        Loop

        'saving the score as a CSV file
        Dim file As System.IO.StreamWriter = Nothing
        Try
            file = My.Computer.FileSystem.OpenTextFileWriter(path, True)
            file.WriteLine(String.Format("{0},{1},{2}", Name.ToUpper, lblScore3.Text, DateTime.Now))
        Finally
            file.Close()
            file = Nothing
        End Try

    End Sub
#End Region

End Class