﻿Public Class Instructions

#Region "Buttons"
    Private Sub Back_Click(sender As Object, e As EventArgs) Handles Back.Click
        Main.Show()
        Me.Hide()
    End Sub

    Private Sub HighScores_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Main.Show()
    End Sub

    Private Sub off_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub
#End Region

#Region "change color of labels"
    Private Sub ColorBack()
        If Back.ForeColor = Color.Cyan Then
            Back.ForeColor = Color.Black
        End If
    End Sub

    Sub ColorChanger(LabelNum)
        If LabelNum.ForeColor = Color.Black Then
            LabelNum.ForeColor = Color.Cyan
        End If
    End Sub

    Private Sub Back_MouseHover(sender As Object, e As EventArgs) Handles Back.MouseHover
        ColorChanger(Back)
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.MouseHover
        ColorBack()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.MouseHover
        ColorBack()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.MouseHover
        ColorBack()
    End Sub
#End Region

    
End Class